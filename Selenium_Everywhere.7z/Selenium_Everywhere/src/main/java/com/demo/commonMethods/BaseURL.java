package com.demo.commonMethods;

public class BaseURL {
	
	public static String URL() {
		
		String url = "https://www.seleniumeasy.com/test/table-search-filter-demo.html";
		
		return url;
	}

}
