package com.demo.Baseclass;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;

import com.demo.commonMethods.BaseURL;
import com.demo.commonMethods.ExplictWait;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

public class Baseclass {
	
	public WebDriver driver;
	public ExtentReports extent;
	public ExtentTest logger;
	
	//@Parameters({"browser"})
	//@BeforeMethod
	public void Baseclass1(String browser) {
		
		extent = new ExtentReports(System.getProperty("user.dir")+"//test-output//Reportsreportextent.html", true);
		
		try {
			if (browser.equalsIgnoreCase("chrome")) {
				System.setProperty("webdriver.chrome.driver", "D://JarFile//chromedriver_win32/chromedriver.exe");
				driver = new ChromeDriver();
			} else if (browser.equalsIgnoreCase("firefox")) {

			}

			else if (browser.equalsIgnoreCase("IE")) {

			} 
		} catch (WebDriverException e) {
			System.out.println(e.getMessage());
		}
		finally {
			System.setProperty("webdriver.chrome.driver", "D://JarFile//chromedriver_win32/chromedriver.exe");
			driver = new ChromeDriver();
		}
		
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS); 	 	
		driver.navigate().to(BaseURL.URL());
		
		driver.manage().window().maximize();
		
		
	}
	
	
	@BeforeMethod
	public void Baseclass1() {
		
		extent = new ExtentReports(System.getProperty("user.dir")+"//test-output//Reportsreportextent.html", true);
		
				System.setProperty("webdriver.chrome.driver", "D://JarFile//chromedriver.exe");
				driver = new ChromeDriver();
				
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS); 	 	
		driver.navigate().to(BaseURL.URL());
		
		driver.manage().window().maximize();
		
		
	}

	
	@AfterTest
	public void endReport() {
		
		extent.flush();
		extent.close();
		
	}
	
	@AfterMethod
	public void getResult(ITestResult result) {
		if(result.getStatus() == ITestResult.FAILURE) {
			logger.log(LogStatus.FAIL, "Test case failed is "+result.getName());
			logger.log(LogStatus.FAIL, "Test case Failed is "+result.getThrowable());
		}
		else if(result.getStatus() == ITestResult.SKIP) {
			logger.log(LogStatus.SKIP, "Test case skiped is "+result.getName());
		}
		
		extent.endTest(logger);
	}

}
